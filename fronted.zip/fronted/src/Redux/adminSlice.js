import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios'

const URL = 'http://localhost:5555/admin'

export const addAdmin = createAsyncThunk('admin/addAdmin', async(data ,{rejectWithValue})=> {
    try {
        const response = await axios.post(`${URL}/addadmin`, data, {
            headers: {
                "Content-Type" : "multipart/form-data"
            }
        })

        console.log(response.data)
        return response.data

    } catch (error) {
        rejectWithValue(error.response.data.message)
    }
})

export const loginAdmin = createAsyncThunk('admin/loginAdmin', async(data, {rejectWithValue})=> {
    try {
        const response = await axios.post(`${URL}/logadmin`, data)
        console.log(response.data)
        sessionStorage.setItem('admin', JSON.stringify(response.data.user))
        return response.data
    } catch (error) {
        rejectWithValue(error.response.data.message)
    }
})


const initialState = {
    admins: [],
    loading: false,
    error: null
}

const adminSlice = createSlice({
    name: 'admin',
    initialState,
    reducers: {},
    extraReducers: (builder)=> {
        builder.addCase(addAdmin.pending, (state, action)=> {
            state.loading = true
            state.error = null
        })

        builder.addCase(addAdmin.fulfilled, (state, action)=> {
            state.loading = false
            state.admins = action.payload
        })

        builder.addCase(addAdmin.rejected, (state, action)=> {
            state.loading = false
            state.error = action.payload
        })


        builder.addCase(loginAdmin.pending, (state, action)=> {
            state.loading = true
            state.error = null
        })

        builder.addCase(loginAdmin.fulfilled, (state, action)=> {
            state.loading = false
            state.admins = action.payload
        })

        builder.addCase(loginAdmin.rejected, (state, action)=> {
            state.loading = false
            state.error = action.payload
        })
    }

})


export default adminSlice.reducer