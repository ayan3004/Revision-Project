import { configureStore } from '@reduxjs/toolkit'
import recipeSlice from '../Redux/recipeSlice'
import adminSlice from '../Redux/adminSlice'

export const store = configureStore({
    reducer: {
        recipe: recipeSlice,
        admin: adminSlice
    }
})

