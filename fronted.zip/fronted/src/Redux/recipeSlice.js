import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios'

const RECIPE_URL = 'http://localhost:5555/recipe'

export const getAllRecipe = createAsyncThunk('recipe/getAllRecipe', async(_, {rejectWithValue})=> {
    try {
        const response = await axios.get(`${RECIPE_URL}`)
        console.log(response.data)
        return response.data.data
    } catch (error) {
        rejectWithValue(error.response.data.message)
    }
})

export const addRecipe = createAsyncThunk('recipe/addRecipe', async(data, {rejectWithValue})=> {
    try {
        const response = await axios.post(`${RECIPE_URL}/addrecipe`, data, {
            headers: {
                "Content-Type": "multipart/form-data"
            }
        })
        console.log(response.data)
        return  response.data
    } catch (error) {
        rejectWithValue(error.response.data.message)
    }
})


export const deleteRecipe = createAsyncThunk('recipe/deleteRecipe', async(id, {rejectWithValue})=> {
    try {
        const response = await axios.delete(`${RECIPE_URL}/delete?id=${id}`)
        console.log(response.data)
        return  response.data
    } catch (error) {
        rejectWithValue(error.response.data.message)
    }
})


const initialState = {
    recipes: [],
    loading: false,
    error: null,
}

const recipeSlice = createSlice({
    name: 'recipe',
    initialState,
    reducers: {},
    extraReducers: (builder)=> {
        builder.addCase(getAllRecipe.pending, (state, action)=> {
            state.loading = true
            state.error = null
        })

        builder.addCase(getAllRecipe.fulfilled, (state, action)=> {
            state.loading = false
            state.recipes = action.payload
        })

        builder.addCase(getAllRecipe.rejected, (state, action)=> {
            state.loading = false
            state.error = action.payload
        })


        builder.addCase(addRecipe.pending, (state, action)=> {
            state.loading = true
            state.error = null
        })

        builder.addCase(addRecipe.fulfilled, (state, action)=> {
            state.loading = false
            state.recipes.push(action.payload)
        })

        builder.addCase(addRecipe.rejected, (state, action)=> {
            state.loading = false
            state.error = action.payload
        })
    
    
        
        builder.addCase(deleteRecipe.pending, (state, action)=> {
            state.loading = true
            state.error = null
        })

        builder.addCase(deleteRecipe.fulfilled, (state, action)=> {
            state.loading = false
        })

        builder.addCase(deleteRecipe.rejected, (state, action)=> {
            state.loading = false
            state.error = action.payload
        })
    }
})

export default recipeSlice.reducer