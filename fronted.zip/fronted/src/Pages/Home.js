import React from 'react'
import { Routes, Route} from 'react-router-dom'
import Dashboard from '../Components/Dashboard/Dashboard'
import Header from '../Components/Header/Header'
import Footer from '../Components/Footer'
import AddRecipe from '../Components/AddRecipe'

const Home = () => {
  return (
    <>

             <Header/>
        <Routes>
            <Route path='dashboard' element={<Dashboard/>} />
            <Route path='addrecipe' element={<AddRecipe/>} />
        </Routes>
            <Footer/>
    
    </>
  )
}

export default Home