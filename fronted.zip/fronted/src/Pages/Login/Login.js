import React, { useState } from 'react'
import './Login.css'
import { useNavigate } from 'react-router-dom'
import {useDispatch, useSelector} from 'react-redux'
import { addAdmin, loginAdmin } from '../../Redux/adminSlice'

const Login = () => {

    const {error, admins} = useSelector((state)=> state.admin)
    const dispatch = useDispatch()
    const navigate = useNavigate()

    const [login, setLogin] = useState(false)
    const [userLogin, setUserLogin] = useState({
        email : '',
        password : ''
    })

    const [newUser, setNewUser] = useState({
        name : '',
        phone : '',
        email : '',
        password : '',
        image : ''

    })


    const handleLogin = (e) => {
        const {name, value} = e.target
        setUserLogin((prevstate)=>({
            ...prevstate,
            [name] : value
        }))
    }

    const SubmitLogin = (e) => {
        e.preventDefault()
        console.log(userLogin)
        try {
            const success = dispatch(loginAdmin(userLogin))
            if(success){
                navigate('/adminpanel/dashboard')
            }
        } catch (error) {
            console.log(error)
        }
    }

    const handleSignup = (e) => {
        const {name, files, value} = e.target
        if(name === 'image'){
            setNewUser((prevstate)=>({
                ...prevstate,
                [name]: files[0]
            }))
        }else{
            setNewUser((prevstate)=> ({
                ...prevstate, 
                [name] : value
            }))
        }
    }

    const SubmitSignup = (e) => {
        e.preventDefault()
        console.log(newUser)
        try {
            const success = dispatch(addAdmin(newUser))
            if(success){
                setLogin(false)
            }            
        } catch (error) {
            console.log(error)
        }
    }

  return (
    <>

<div className="auth-container">
    {login == false ? (

        <div className="form-container">
            <h2>Login</h2>
            <form onSubmit={SubmitLogin}>
                <input type="email" name="email"  placeholder="Your Email" onChange={handleLogin} required />
                <input type="password" name="password" placeholder="Enter Password" onChange={handleLogin} required />
                <button type="submit">Login</button>
                <p>Don't have an account? <span onClick={()=> setLogin(true)}>Sign up</span></p>
            </form>
        </div>

    ) : (


        <div className="form-container">
            <h2>Sign Up</h2>
            <form onSubmit={SubmitSignup}>
                <input type="text" name="name" value={newUser.name} onChange={handleSignup} placeholder="Full Name" required />
                <input type="email" name="email" value={newUser.email} onChange={handleSignup} placeholder="Your Email" required />
                <input type="text" name="phone" value={newUser.phone} onChange={handleSignup} placeholder="Your Phone" required />
                <input type="password" name="password" value={newUser.password} onChange={handleSignup} placeholder="Enter Password" required />
                <input type="file" name='image' onChange={handleSignup} />
                <button type="submit">Sign Up</button>
                <p>Already have an account? <span onClick={()=> setLogin(false)}>Login</span></p>
            </form>
        </div>

    )}

    </div>


    </>
  )
}

export default Login