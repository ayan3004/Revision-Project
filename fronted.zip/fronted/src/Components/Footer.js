import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>
        <center>
            <p>© Recipe Sharing App, All Right Reserved. Designed By Ayan Sangani</p>
         </center>
    </div>
  )
}

export default Footer