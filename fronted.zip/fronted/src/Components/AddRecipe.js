import React, { useState } from 'react'
import {useDispatch, useSelector} from 'react-redux'
import {useNavigate} from 'react-router-dom'
import { addRecipe } from '../Redux/recipeSlice'

const AddRecipe = () => {

    const navigate = useNavigate()
    const dispatch = useDispatch()

    const {error} = useSelector((state)=> state.recipe)

    const [newRecipe, setNewRecipe] = useState({
        name: '',
        calories: '',
        description: '',
        image: ''
    })

    const handleRecipe = (e) => {
        const {name, value, files} = e.target
        
        if(name === 'image'){
            setNewRecipe((prevstate)=>({
                ...prevstate,
                [name] : files[0]
            }))
        }else{
            setNewRecipe((prevstate)=> ({
                ...prevstate,
                [name]: value
            }))
        }
    }

    const SubmitRecipe = (e) => {
        e.preventDefault();
        try {
            const success = dispatch(addRecipe(newRecipe))
            if(success){
                navigate('/adminpanel/dashboard')
            }
        } catch (error) {
            console.log(error)
        }
    }

  return (
    <div className='auth-container'>

    <div className="form-container">
            <h2>Add Recipe</h2>
            <form onSubmit={SubmitRecipe}>
                <input type="text" name="name" value={newRecipe.name} onChange={handleRecipe} placeholder="Recipe Name" required />
                <input type="text" name="calories" value={newRecipe.calories} onChange={handleRecipe} placeholder="Calories" required />
                <input type="text" name="description" value={newRecipe.description} onChange={handleRecipe} placeholder="Recipe's Description" required />
                <input type="file" name='image' onChange={handleRecipe} />
                <button type="submit">Add Recipe</button>
            </form>
        </div>

    </div>
  )
}

export default AddRecipe