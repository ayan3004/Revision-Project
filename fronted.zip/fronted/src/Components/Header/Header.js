import React, { useEffect, useState } from 'react'
import './Header.css'
import {Link} from 'react-router-dom'

const Header = () => {

  const [user, setUser] = useState([])

  useEffect(()=>{
    const data = JSON.parse(sessionStorage.getItem('admin'))
    setUser(data)
  },[])
  return (
    <>
    
    <header className="header">
        <div className="logo">RecipeApp</div>
        <div className="search-bar">
            <input type="text" placeholder="Search recipes..." />
        </div>
        <Link to='/adminpanel/addrecipe' className='text-white'>Add Recipe</Link>
        <div className="profile-icon">
            <img src={`http://localhost:5555/uploades/admin/${user.image}`} alt="Profile" />
        </div>
    </header>
    </>
  )
}

export default Header