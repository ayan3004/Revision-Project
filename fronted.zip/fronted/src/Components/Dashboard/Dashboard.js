import React, { useEffect } from 'react'
import './Dashboard.css'
import {useDispatch, useSelector} from 'react-redux'
import { deleteRecipe, getAllRecipe } from '../../Redux/recipeSlice'

const Dashboard = () => {

    const dispatch = useDispatch()
    const {loading, error, recipes} = useSelector((state)=> state.recipe)

    useEffect(()=> {
        dispatch(getAllRecipe())
        console.log(recipes)
    }, [dispatch])

    const handleDelete = (id) => {
        dispatch(deleteRecipe(id))
    }

  return (
    <div className='dashboard'>
        {recipes.map((el, i)=> (
        <div className="cards" key={i}>
            <div className="cards-header">
                <img src={`http://localhost:5555/uploades/Recipe/${el.image}`} alt="" /> 
                <h3 className='title fs-4'>{el.name}<br />
                    <span>{el.calories}</span>
                </h3>
           </div>
           <div className="cards-body">
                <h5>Recipe :</h5>
                <p>{el.description}</p>
           </div>
           <div className="cards-footer">
           <button type="button" className="btn btn-primary">EDIT</button>
           <button type="button" className="btn btn-danger" onClick={()=> handleDelete(el._id)}>DELETE</button>
           </div>
        </div>
        ))}




    </div>
  )
}

export default Dashboard